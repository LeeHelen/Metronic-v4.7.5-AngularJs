angular.module('App.Login', []).controller('LoginController', ['$rootScope', '$scope', '$http', function ($rootScope, $scope, $http) {
	$rootScope.settings = {
		restApiBasePath: "http://localhost:52151"
	};
	$scope.model = {
		ShortName: "",
		Password: ""
	};
	// 从sessionStorage删除所有保存的数据
	sessionStorage.clear();

	$.backstretch([
		"../assets/pages/media/bg/1.jpg",
		"../assets/pages/media/bg/2.jpg",
		"../assets/pages/media/bg/3.jpg",
		"../assets/pages/media/bg/4.jpg"
	], {
			fade: 1000,
			duration: 8000
		});
	var handleLogin = function () {	
		$('.login-form').validate({
			errorElement: 'span', //default input error message container
			errorClass: 'help-block', // default input error message class
			focusInvalid: false, // do not focus the last invalid input
			rules: {
				shortName: {
					required: true
				},
				password: {
					required: true
				},
				remember: {
					required: false
				}
			},

			messages: {
				shortName: {
					required: "ShortName is required."
				},
				password: {
					required: "Password is required."
				}
			},

			invalidHandler: function (event, validator) { //display error alert on form submit   
				$('.alert-danger', $('.login-form')).show();
			},

			highlight: function (element) { // hightlight error inputs
				$(element)
					.closest('.form-group').addClass('has-error'); // set error class to the control group
			},

			success: function (label) {
				label.closest('.form-group').removeClass('has-error');
				label.remove();
			},

			errorPlacement: function (error, element) {
				error.insertAfter(element.closest('.input-icon'));
			},

			submitHandler: function (form) {
				// form.submit();
				$http({
					method: 'POST',
					url: $rootScope.settings.restApiBasePath + '/users/simplifyquery',
					headers: {
						//"Content-Type": "application/x-www-form-urlencoded",
						"Content-Type": "application/json;charset=utf-8",
						"Accept": "application/json"
					},
					data: $scope.model  //$.param($scope.user)  
				}).then(function successCallback(response) {
					// 请求成功执行代码
					if(response && response.status == 200 && response.data) {
						// 保存数据到sessionStorage
						sessionStorage.setItem('user', angular.toJson({
							ShortName: response.data.ShortName || "",
							Password: response.data.Password || "",
							EnglishName: response.data.EnglishName || ""
						}));
						window.location.href = "/";	
					} 
					else {
						$('.alert-danger', $('.login-form')).show();
					}
					//BootstrapToastr.handleToastr("success", "success!");
				}, function errorCallback(response) {
					// 请求失败执行代码
				});
				return false;
			}
		});

		$('.login-form input').keypress(function (e) {
			if (e.which == 13) {
				if ($('.login-form').validate().form()) {
					$('.login-form').submit();
				}
				return false;
			}
		});
	}
	handleLogin();
}]);