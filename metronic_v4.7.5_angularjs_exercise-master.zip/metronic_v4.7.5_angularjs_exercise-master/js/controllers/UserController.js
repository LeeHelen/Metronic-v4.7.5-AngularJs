/* Setup blank page controller */
angular.module('App').controller('UserController', ['$rootScope', '$scope', 'settings', '$http', 'BootstrapToastr', function ($rootScope, $scope, settings, $http, BootstrapToastr) {
    $scope.$on('$viewContentLoaded', function () {
        // initialize core components
        App.initAjax();

        // set default layout mode
        $rootScope.settings.layout.pageContentWhite = true;
        $rootScope.settings.layout.pageBodySolid = true;
        $rootScope.settings.layout.pageSidebarClosed = false;

        //init data
        var model = $scope.model = {
            ChineseName: "",
            EnglishName: $rootScope.$settings.user.EnglishName,  
            ShortName: $rootScope.$settings.user.ShortName,
            Password: $rootScope.$settings.user.Password,
            NewPassword: "",
            HeadPortrait: "../assets/pages/img/AAAAAA&text=no+image.png",
            Email: "",
            MobileNumber: "",
            Occupation: "",
            About: ""
        };
        console.log(model);
        $scope.pageLoad = function () {
            //init Personal Info
            $http({
                method: 'POST',
                url: settings.restApiBasePath + '/users/simplifyquery',
                headers: {
                    //"Content-Type": "application/x-www-form-urlencoded",
                    "Content-Type": "application/json;charset=utf-8",
                    "Accept": "application/json"
                },
                // data: { ShortName: "kl1m" }
                data: $scope.model
            }).then(function successCallback(response) {
                // 请求成功执行代码
                if (response && response.data) {
                    $scope.model = angular.fromJson(response.data);
                }
            }, function errorCallback(response) {
                // 请求失败执行代码
            });
        };
        $scope.pageLoad();

        //Save Personal Info
        $scope.SavePersonalInfo = function () {
            //debugger;
            $http({
                method: 'POST',
                url: settings.restApiBasePath + '/users/save',
                headers: {
                    //"Content-Type": "application/x-www-form-urlencoded",
                    "Content-Type": "application/json;charset=utf-8",
                    "Accept": "application/json"
                },
                data: $scope.model
            }).then(function successCallback(response) {
                // 请求成功执行代码
                if(response && response.data) {
                    BootstrapToastr.handleToastr("success", "success!");
                    $scope.model = response.data;
                    sessionStorage.setItem('user', angular.toJson({
                        ShortName: response.data.ShortName || "",
                        Password: response.data.Password || "",
                        EnglishName: response.data.EnglishName || ""
                    }));
                }
            }, function errorCallback(response) {
                // 请求失败执行代码
            });
        };

        //Upload img
        $scope.ChangeAvatar = function (){
            $scope.SavePersonalInfo();
        };

        //Save Change Password
        $scope.SaveChangePassword = function () {
            $http({
                method: 'POST',
                url: settings.restApiBasePath + '/users/save',
                headers: {
                    //"Content-Type": "application/x-www-form-urlencoded",
                    "Content-Type": "application/json;charset=utf-8",
                    "Accept": "application/json"
                },
                data: $scope.model
            }).then(function successCallback(response) {
                // 请求成功执行代码
                if(response && response.data) {
                    BootstrapToastr.handleToastr("success", "success!");
                    // $scope.model = response.data;
                    // sessionStorage.setItem('user', angular.toJson({
                    //     ShortName: response.data.ShortName || "",
                    //     Password: response.data.Password || "",
                    //     EnglishName: response.data.EnglishName || ""
                    // }));
                    window.location.href = "/views/login.html"
                }
            }, function errorCallback(response) {
                // 请求失败执行代码
            });
        };

    });
}]).directive('ngFile', [function () {
    return {
        restrict: 'A',
        link: function(scope, element, attrs, ngModel) {
            element.bind('change', function(event){
                // var file = document.querySelector('input[type=file]').files[0];
                var file = (event.target || event.srcElement).files[0];
                var reader = new FileReader();
                reader.readAsDataURL(file);
                reader.onload = function() {
                    scope.model.HeadPortrait = this.result;
                }
                reader.onerror = function() {
                    console.log("error");
                }
            });
        }
    };
}]);
